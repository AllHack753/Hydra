#define _UNICODE 1
#define UNICODE 1
#include "wincrt1.c"
